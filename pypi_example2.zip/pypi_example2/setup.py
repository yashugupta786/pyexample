import setuptools
from setuptools import setup
setup(name="packageyashu",
version="0.1",
description="This is code with yashu package",
long_description = "This is a very very long description",
author="yashu",
packages=setuptools.find_packages(),
install_requires=["Flask==2.2.2"],
classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
python_requires='>=3.7',
)